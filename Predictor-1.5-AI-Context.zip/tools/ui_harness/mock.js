/* Заглушка Python-моста для проверки UI в браузере */
(function () {
  const now = () => new Date().toTimeString().slice(0, 8);
  const settings = {
    running: true,
    active_sport: "table_tennis",
    poll_interval_sec: 20,
    odds_check_enabled: true,
    debug_verbose: true,
    bet_size_percent: 2.0,
    telegram: { enabled: true, token: "", chat_id: "" },
    model_thresholds: { streak: 0.25, window: 0.25, markov1: 0.25, markov2: 0.25, recency: 0.25, base_rate: 0.25 },
    required_models: ["streak", "window"],
    allowed_bets: { "П1": true, "П2": true, "ТБ18.5": true, "ТМ18.5": false },
    allowed_sets: { set1: true, set2: true, set3: true, set4: false, set5: false },
    general_filters: { min_strong: 2, min_agreement: 0.4, min_confidence: 0.2, min_active: 2, vote_weight_base: 0.3 },
    min_h2h_matches: 5,
    engine: { streak_min: 3, window_size: 10, window_min_hits: 6, markov_min_sample: 5, recency_decay: 0.85, base_rate_min_n: 10, prob_threshold: 18.5 },
    reports: { hourly: true, daily: true, daily_hour: 23, daily_minute: 55 },
    notifications: { on_signal: true, on_error: true, on_result: true },
  };

  const sports = [
    { id: "table_tennis", name: "Настольный теннис", short: "Наст. теннис", icon: "🏓", has_draw: false, bets: [{ type: "winner" }, { type: "total" }] },
    { id: "football", name: "Футбол", short: "Футбол", icon: "⚽", has_draw: true, bets: [{ type: "winner" }, { type: "total" }, { type: "handicap" }, { type: "btts" }] },
    { id: "hockey", name: "Хоккей", short: "Хоккей", icon: "🏒", has_draw: true, bets: [{ type: "winner" }, { type: "total" }, { type: "handicap" }, { type: "btts" }] },
    { id: "basketball", name: "Баскетбол", short: "Баскетбол", icon: "🏀", has_draw: false, bets: [{ type: "winner" }, { type: "total" }, { type: "handicap" }] },
    { id: "volleyball", name: "Волейбол", short: "Волейбол", icon: "🏐", has_draw: false, bets: [{ type: "winner" }, { type: "total" }, { type: "handicap" }] },
    { id: "tennis", name: "Большой теннис", short: "Теннис", icon: "🎾", has_draw: false, bets: [{ type: "winner" }, { type: "total" }, { type: "handicap" }] },
  ];

  let logId = 0;
  const logs = [];
  const messages = [
    ["INFO", "Движок запущен (интервал 20 с)"],
    ["INFO", "📊 Всего матчей: 24, скоро: 7"],
    ["INFO", "Анализ: Иванов А. vs Петров С."],
    ["INFO", "      ✅ Партия 1 (П1/П2): П1 | Модели: streak=T1(71%), window=T1(64%)"],
    ["INFO", "✅ Сигналов: 2 (Иванов А. vs Петров С.)"],
    ["WARNING", "Telegram не настроен — сигнал сохранён локально"],
    ["INFO", "Анализ: Сидоров К. vs Кузнецов Д."],
    ["INFO", "      ⛔ Партия 1 (ТБ18.5/ТМ18.5): agreement 12.0% < 20%"],
    ["ERROR", "Очередь: таймаут соединения с d.betcity.by"],
    ["INFO", "Цикл завершён: проверено 7, сигналов 2"],
  ];
  messages.forEach(([level, message]) => {
    logId += 1;
    logs.push({ id: logId, ts: now(), ts_full: "2026-10-19 " + now(), level, message });
  });

  const queue = [
    { match_id: "1", sport: "table_tennis", sport_name: "Наст. теннис", team1: "Иванов А.", team2: "Петров С.", league: "Pro League", date: "19.10 14:30", score: "0:0", started: false, processed: false, sent: true, odds: { p1: 1.72, p2: 2.05 },
      prediction: { sent_at: "2026-10-19T14:30:00", wins: 1, losses: 1, pending: 0, items: [
        { target: "set1", kind: "winner", label: "Партия 1 (П1/П2)", verdict: "П1", success: true, score: "11:7", total: 18 },
        { target: "set1", kind: "total", label: "Партия 1 (ТБ18.5/ТМ18.5)", verdict: "ТБ 18.5", success: false, score: "11:7", total: 18 },
      ] } },
    { match_id: "2", sport: "table_tennis", sport_name: "Наст. теннис", team1: "Сидоров К.", team2: "Кузнецов Д.", league: "TT Cup", date: "19.10 14:45", score: "1:1", started: true, processed: false, sent: false, odds: { p1: 1.95, p2: 1.82 } },
    { match_id: "3", sport: "table_tennis", sport_name: "Наст. теннис", team1: "Морозов И.", team2: "Волков П.", league: "Setka Cup", date: "19.10 15:00", score: "0:0", started: false, processed: true, sent: false, odds: { p1: 2.10, p2: 1.68 } },
  ];

  const results = [
    { id: "a", sport: "table_tennis", sport_name: "Наст. теннис", team1: "Иванов А.", team2: "Петров С.", league: "Pro League", date: "19.10",
      sent_at: "2026-10-19T14:30:00", wins: 1, losses: 1, pending: 0, checked: true,
      final_score: "11:7 9:11 11:5",
      rows: [
        { target: "set1", kind: "winner", label: "Партия 1 (П1/П2)", verdict: "П1", reason: "Модели: streak=T1(71%), window=T1(64%), markov1=T1(58%)", confidence: 62, agreement: 71, strong: 4, success: true, score: "11:7", total: 18 },
        { target: "set1", kind: "total", label: "Партия 1 (ТБ18.5/ТМ18.5)", verdict: "ТБ 18.5", reason: "Модели: markov1=TO(52%), base_rate=TO(48%), recency=TO(55%)", confidence: 44, agreement: 55, strong: 3, threshold: 18.5, success: false, score: "11:7", total: 18 },
      ] },
    { id: "b", sport: "table_tennis", sport_name: "Наст. теннис", team1: "Сидоров К.", team2: "Кузнецов Д.", league: "TT Cup", date: "18.10",
      sent_at: "2026-10-18T09:15:00", wins: 1, losses: 0, pending: 1, checked: false, final_score: "",
      rows: [
        { target: "set2", kind: "winner", label: "Партия 2 (П1/П2)", verdict: "П2", reason: "Модели: window=T2(58%), streak=T2(61%)", confidence: 51, agreement: 60, strong: 3, success: true, score: "9:11", total: 20 },
        { target: "set3", kind: "winner", label: "Партия 3 (П1/П2)", verdict: "П1", reason: "Модели: markov2=T1(57%)", confidence: 55, agreement: 64, strong: 2, success: null, score: "", total: null },
      ] },
  ];

  const predictions = [
    {
      id: "a", sport: "table_tennis", sport_name: "Наст. теннис", team1: "Иванов А.", team2: "Петров С.", league: "Pro League", date: "19.10",
      sent_at: "2026-10-19T14:30:00", wins: 1, losses: 1, pending: 0, checked: true,
      predictions: [
        { target: "set1", label: "Партия 1 (П1/П2)", verdict: "П1" },
        { target: "set1", label: "Партия 1 (ТБ18.5/ТМ18.5)", verdict: "ТБ 18.5" },
      ],
      results: [
        { target: "set1", success: true, score: "11:7" },
      ],
    },
    {
      id: "b", sport: "table_tennis", sport_name: "Наст. теннис", team1: "Сидоров К.", team2: "Кузнецов Д.", league: "TT Cup", date: "19.10",
      sent_at: "2026-10-19T13:10:00", wins: 2, losses: 0, pending: 1, checked: false,
      predictions: [
        { target: "set1", label: "Партия 1 (П1/П2)", verdict: "П2" },
        { target: "set2", label: "Партия 2 (П1/П2)", verdict: "П2" },
        { target: "set2", label: "Партия 2 (ТБ18.5/ТМ18.5)", verdict: "ТМ 18.5" },
      ],
      results: [
        { target: "set1", success: true },
        { target: "set2", success: true },
      ],
    },
  ];

  const stats = {
    matches: 2,
    total: { preds: 5, wins: 3, losses: 1, pending: 1 },
    today: { preds: 5, wins: 3, losses: 1, pending: 1 },
    hit_rate: 75.0,
    today_hit_rate: 75.0,
    by_target: [
      { key: "set1:total", total: 2, wins: 1, losses: 1, hit_rate: 50.0 },
      { key: "set1:winner", total: 2, wins: 2, losses: 0, hit_rate: 100.0 },
      { key: "set2:winner", total: 1, wins: 1, losses: 0, hit_rate: 100.0 },
    ],
    by_sport: [
      { sport: "table_tennis", name: "Наст. теннис", preds: 5, wins: 3, losses: 1, pending: 1, hit_rate: 75.0 },
      { sport: "football", name: "Футбол", preds: 2, wins: 1, losses: 1, pending: 0, hit_rate: 50.0 },
    ],
  };

  const ctorCatalog = {
    sport: "table_tennis",
    sport_name: "Настольный теннис",
    default_total: 18.5,
    period_word: "Партия",
    bets: [{ type: "winner" }, { type: "total" }],
    metrics: [
      { id: "h2h.count", label: "Сколько очных встреч найдено", group: "Очные встречи", type: "number", args: {}, unit: "", hint: "" },
      { id: "h2h.win_rate", label: "Процент побед {side} в очных за {window}", group: "Очные встречи", type: "number", args: { side: "p1", window: 10 }, unit: "%" },
      { id: "h2h.streak", label: "Текущая серия побед {side} в очных", group: "Очные встречи", type: "number", args: { side: "p1" }, unit: "игр" },
      { id: "h2h.last_winner", label: "Победитель последней очной встречи", group: "Очные встречи", type: "enum", args: {}, options: [["p1", "Игрок 1"], ["p2", "Игрок 2"]] },
      { id: "h2h.over_rate", label: "Доля ТБ{threshold} в {set} партии очных за {window}", group: "Очные встречи", type: "number", args: { window: 10, set: 1, threshold: 18.5 }, unit: "%" },
      { id: "p.recent.win_rate", label: "Процент побед {side} за {window} игр", group: "Форма игрока", type: "number", args: { side: "p1", window: 5 }, unit: "%" },
      { id: "p.recent.avg_set_total", label: "Средний тотал партии {side} за {window} игр", group: "Форма игрока", type: "number", args: { side: "p1", window: 5 }, unit: "очк." },
      { id: "p.recent.set_win_rate", label: "Процент побед {side} в {set} партии за {window} игр", group: "Форма игрока", type: "number", args: { side: "p1", window: 5, set: 1 }, unit: "%" },
      { id: "p.recent.last_result", label: "Результат последней игры {side}", group: "Форма игрока", type: "enum", args: { side: "p1" }, options: [["win", "Победа"], ["loss", "Поражение"]] },
      { id: "cmp.avg_set_total_mean", label: "Средний тотал партии по форме обоих за {window} игр", group: "Сравнение игроков", type: "number", args: { window: 5 }, unit: "очк." },
      { id: "cmp.win_rate_lead", label: "Кто лучше по проценту побед за {window} игр", group: "Сравнение игроков", type: "enum", args: { window: 5 }, options: [["p1", "Игрок 1"], ["p2", "Игрок 2"], ["tie", "Равно"]] },
      { id: "odds.p1", label: "Коэффициент на игрока 1", group: "Коэффициенты", type: "number", args: {} },
      { id: "odds.p2", label: "Коэффициент на игрока 2", group: "Коэффициенты", type: "number", args: {} },
      { id: "odds.available", label: "Коэффициенты доступны", group: "Коэффициенты", type: "bool", args: {} },
      { id: "match.league", label: "Название лиги", group: "Матч", type: "string", args: {} },
      { id: "match.minutes_to_start", label: "Минут до начала матча", group: "Матч", type: "number", args: {}, unit: "мин" },
    ],
    args: {
      side: { label: "Игрок", kind: "select", default: "p1", options: [["p1", "Игрок 1"], ["p2", "Игрок 2"]] },
      window: { label: "Игр", kind: "number", default: 5, min: 1, max: 20, step: 1 },
      set: { label: "Партия", kind: "select", default: 1, options: [[1, "1-я"], [2, "2-я"], [3, "3-я"], [4, "4-я"], [5, "5-я"]] },
      threshold: { label: "Тотал", kind: "number", default: 18.5, min: 0, max: 100, step: 0.5 },
    },
    operators: {
      number: [["gt", "Больше"], ["gte", "Больше или равно"], ["lt", "Меньше"], ["lte", "Меньше или равно"], ["eq", "Равно"], ["neq", "Не равно"], ["between", "Между"], ["exists", "Есть данные"], ["not_exists", "Нет данных"]],
      string: [["eq", "Равно"], ["neq", "Не равно"], ["contains", "Содержит"], ["not_contains", "Не содержит"], ["in", "Одно из"], ["not_in", "Не одно из"], ["starts_with", "Начинается с"], ["ends_with", "Заканчивается на"], ["exists", "Есть"], ["not_exists", "Нет"]],
      enum: [["eq", "Равно"], ["neq", "Не равно"], ["in", "Одно из"], ["not_in", "Не одно из"], ["exists", "Есть"], ["not_exists", "Нет"]],
      bool: [["is", "Равно"], ["exists", "Есть"], ["not_exists", "Нет"]],
    },
    enum_labels: {},
    side_labels: { p1: "игрока 1", p2: "игрока 2" },
  };

  let ctorRules = [
    {
      id: "r1", name: "ТБ 18.5: форма + последняя очная", enabled: true, priority: 100, stop: false,
      conditions: { logic: "and", conditions: [
        { metric: "h2h.last_winner", args: {}, op: "eq", value: "p1" },
        { metric: "p.recent.avg_set_total", args: { side: "p1", window: 5 }, op: "gt", value: 19 },
      ] },
      action: { type: "total", targets: [1], side: "over", threshold: 18.5, confidence: 0.65 },
      summary: "ЕСЛИ Победитель последней очной встречи = Игрок 1 И Средний тотал партии игрока 1 за 5 игр > 19 очк. → ТБ 18.5, партии 1",
      conditions_text: "Победитель последней очной встречи (= Игрок 1) = Игрок 1 И Средний тотал партии игрока 1 (> 19)",
      action_text: "ТБ 18.5, партии 1",
    },
    {
      id: "r2", name: "Пропуск: кэф ниже 1.5", enabled: false, priority: 90, stop: false,
      conditions: { logic: "or", conditions: [
        { metric: "odds.p1", args: {}, op: "lt", value: 1.5 },
        { metric: "odds.p2", args: {}, op: "lt", value: 1.5 },
      ] },
      action: { type: "skip", targets: [1], side: "auto", threshold: 18.5, confidence: 0.6 },
      summary: "ЕСЛИ (Коэффициент на игрока 1 < 1.5 ИЛИ Коэффициент на игрока 2 < 1.5) → пропустить матч",
      conditions_text: "Коэффициент на игрока 1 < 1.5 ИЛИ Коэффициент на игрока 2 < 1.5",
      action_text: "пропустить матч",
    },
  ];

  const ctorPresets = [
    { name: "ТБ 18.5: оба верховые", category: "Тоталы", description: "У каждого ТБ 18.5 в партиях проходит минимум в 60% последних игр.", source: "PingPongBets · Over/Under", rule: { name: "ТБ 18.5: оба верховые", conditions: { logic: "and", conditions: [{ metric: "p.recent.over_rate", args: { side: "p1", window: 5, threshold: 18.5 }, op: "gte", value: 60 }] }, action: { type: "total", targets: [1, 2], side: "over", threshold: 18.5, confidence: 0.62 } } },
    { name: "ТБ 18.5: очные верховые", category: "Тоталы", description: "В 7 из 10 очных 1-я партия была ТБ 18.5.", source: "Table Tennis Totals", rule: { name: "ТБ 18.5: очные верховые", conditions: { logic: "and", conditions: [{ metric: "h2h.over_rate", args: { window: 10, set: 1, threshold: 18.5 }, op: "gte", value: 70 }] }, action: { type: "total", targets: [1], side: "over", threshold: 18.5, confidence: 0.64 } } },
    { name: "П1: форма + серия", category: "Победитель", description: "Игрок 1 берёт 60%+ последних игр и идёт на серии 2+ побед.", source: "SmartBettingGuide", rule: { name: "П1: форма + серия", conditions: { logic: "and", conditions: [{ metric: "p.recent.win_rate", args: { side: "p1", window: 5 }, op: "gte", value: 60 }] }, action: { type: "winner", targets: [1], side: "p1", threshold: 18.5, confidence: 0.6 } } },
    { name: "П2: очное доминирование", category: "Победитель", description: "Игрок 2 выиграл 60%+ очных при их количестве от пяти.", source: "Table Tennis Totals", rule: { name: "П2: очное доминирование", conditions: { logic: "and", conditions: [{ metric: "h2h.win_rate", args: { side: "p2", window: 10 }, op: "gte", value: 60 }] }, action: { type: "winner", targets: [1], side: "p2", threshold: 18.5, confidence: 0.62 } } },
    { name: "Пропуск: мало очных", category: "Фильтры", description: "Меньше трёх очных встреч — статистике нельзя доверять.", source: "Table Tennis Totals", rule: { name: "Пропуск: мало очных", conditions: { logic: "and", conditions: [{ metric: "h2h.count", args: {}, op: "lt", value: 3 }] }, action: { type: "skip", targets: [1], side: "auto", threshold: 18.5, confidence: 0.6 } } },
    { name: "ТБ 18.5: равные + верховые", category: "Комбинированные", description: "Ровная форма ±15 п.п. и средний тотал обоих от 18.5.", source: "DeuceLab · рынки", rule: { name: "ТБ 18.5: равные + верховые", conditions: { logic: "and", conditions: [{ metric: "cmp.win_rate_diff", args: { window: 5 }, op: "lte", value: 15 }, { metric: "cmp.avg_set_total_mean", args: { window: 5 }, op: "gte", value: 18.5 }] }, action: { type: "total", targets: [1, 2], side: "over", threshold: 18.5, confidence: 0.6 } } },
  ];

  function withSummaries(rules) {
    return rules.map(r => Object.assign({}, r, {
      summary: r.summary || ("ЕСЛИ " + (r.conditions_text || "условия") + " → " + (r.action_text || "")),
    }));
  }

  function analyzerRow(metric, args, op, value, text, lossShare, winShare, lossHits, winHits, examples) {
    const n = 12;
    return {
      metric, args, op, value,
      condition: { metric, args, op, value },
      text, unit: "%",
      coverage: 91.7,
      win_hits: winHits, win_n: n, win_share: winShare,
      loss_hits: lossHits, loss_n: n, loss_share: lossShare,
      lift: Math.round((winShare - lossShare) * 10) / 10,
      failure_score: Math.round(Math.max(0, lossShare - winShare) * lossShare) / 100,
      success_score: Math.round(Math.max(0, winShare - lossShare) * winShare) / 100,
      examples,
    };
  }

  const analyzerExamples = [
    { teams: "Иванов А. — Петров С.", verdict: "ТБ 18.5", score: "11:6, 9:11, 11:4", total: 21, sent_at: "18.10 14:30" },
    { teams: "Сидоров К. — Кузнецов Д.", verdict: "ТМ 18.5", score: "5:11, 11:8, 7:11", total: 15, sent_at: "18.10 16:10" },
    { teams: "Морозов И. — Волков П.", verdict: "П1", score: "11:9, 8:11, 11:7", total: 23, sent_at: "18.10 18:45" },
  ];

  function analyzerPayload(opts) {
    opts = opts || {};
    const kind = opts.kind || "all";
    const target = opts.target || "";
    const minGroup = Number(opts.min_group || 3);
    const minLift = Number(opts.min_lift || 20);
    const base = {
      ok: true,
      options: { kind, target, min_group: minGroup, min_lift: minLift, min_hits: 2,
        sport: opts.sport === "all" ? "" : (opts.sport || settings.active_sport) },
      observations: { total: 24, wins: 12, losses: 12, with_stats: 31 },
      min_group: minGroup,
      sufficient: true,
      generated_at: "20.10.2026 12:34",
    };
    if (target && target !== "set1") {
      return Object.assign({}, base, {
        observations: { total: 0, wins: 0, losses: 0, with_stats: 31 },
        sufficient: false,
        hint: "Мало данных для вывода: нужно минимум " + minGroup +
              " удачных и " + minGroup + " неудачных прогнозов, а сейчас 0 и 0.",
        failure: [], success: [], combos: { failure: [], success: [] }, means: [],
      });
    }
    if (kind === "winner") {
      return Object.assign({}, base, {
        observations: { total: 0, wins: 0, losses: 0, with_stats: 31 },
        sufficient: false,
        hint: "Мало данных для вывода: нужно минимум " + minGroup +
              " удачных и " + minGroup + " неудачных прогнозов, а сейчас 0 и 0.",
        failure: [], success: [], combos: { failure: [], success: [] }, means: [],
      });
    }
    const failure = [
      analyzerRow("p.recent.avg_set_total", { side: "p1", window: 5 }, "lte", 16,
        "Средний тотал партии игрока 1 за 5 игр ≤ 16", 100, 0, 12, 0, analyzerExamples),
      analyzerRow("p.recent.over_rate", { side: "p1", window: 5, threshold: 18.5 }, "lte", 20,
        "Доля ТБ18.5 в партиях игрока 1 за 5 игр ≤ 20%", 91.7, 8.3, 11, 1, analyzerExamples.slice(0, 1)),
      analyzerRow("h2h.avg_set_total", { window: 10 }, "lte", 17,
        "Средний тотал партии в очных встречах ≤ 17", 83.3, 16.7, 10, 2, analyzerExamples.slice(0, 2)),
      analyzerRow("p.recent.avg_match_total", { side: "p1", window: 5 }, "lte", 34,
        "Средний тотал матча игрока 1 за 5 игр ≤ 34", 75, 25, 9, 3, analyzerExamples),
      analyzerRow("odds.p1", { side: "p1" }, "gte", 2.3,
        "Кэф на игрока 1 ≥ 2.30", 66.7, 33.3, 8, 4, analyzerExamples.slice(0, 1)),
      analyzerRow("p.recent.win_rate", { side: "p1", window: 5 }, "lte", 40,
        "Доля побед игрока 1 за 5 игр ≤ 40%", 58.3, 25, 7, 3, analyzerExamples),
      analyzerRow("cmp.avg_set_total_lead", {}, "eq", "p2",
        "Средний тотал партии больше у игрока 2", 50, 33.3, 6, 4, analyzerExamples),
    ];
    const success = [
      analyzerRow("p.recent.avg_set_total", { side: "p1", window: 5 }, "gte", 20,
        "Средний тотал партии игрока 1 за 5 игр ≥ 20", 0, 100, 0, 12, analyzerExamples),
      analyzerRow("p.recent.over_rate", { side: "p1", window: 5, threshold: 18.5 }, "gte", 80,
        "Доля ТБ18.5 в партиях игрока 1 за 5 игр ≥ 80%", 8.3, 91.7, 1, 11, analyzerExamples.slice(0, 1)),
      analyzerRow("h2h.last_winner", {}, "is", "p1",
        "Последняя очная встреча за игроком 1", 16.7, 83.3, 2, 10, analyzerExamples.slice(0, 2)),
      analyzerRow("p.recent.avg_set_points", { side: "p1", window: 5 }, "gte", 6,
        "Средние очки игрока 1 в партии ≥ 6", 25, 75, 3, 9, analyzerExamples),
      analyzerRow("cmp.win_rate_lead", {}, "eq", "p1",
        "Доля побед выше у игрока 1", 33.3, 66.7, 4, 8, analyzerExamples.slice(0, 1)),
      analyzerRow("p.recent.streak", { side: "p1" }, "gte", 3,
        "Серия побед игрока 1 ≥ 3", 25, 58.3, 3, 7, analyzerExamples),
      analyzerRow("odds.favorite", {}, "is", "p1",
        "Фаворит букмекера — игрок 1", 33.3, 50, 4, 6, analyzerExamples),
    ];
    const combo = (left, right, winShare, lossShare) => ({
      conditions: [left.condition, right.condition],
      texts: [left.text, right.text],
      text: left.text + " И " + right.text,
      win_hits: Math.round(winShare / 100 * 12), win_n: 12, win_share: winShare,
      loss_hits: Math.round(lossShare / 100 * 12), loss_n: 12, loss_share: lossShare,
      lift: Math.round((winShare - lossShare) * 10) / 10,
      score: Math.round((winShare - lossShare) * winShare) / 100,
    });
    return Object.assign({}, base, {
      failure: failure,
      success: success,
      combos: {
        failure: [
          combo(failure[1], failure[4], 0, 83.3),
          combo(failure[0], failure[2], 8.3, 75),
        ],
        success: [
          combo(success[0], success[2], 83.3, 0),
        ],
      },
      means: [
        { metric: "p.recent.over_rate", args: { side: "p1", window: 5, threshold: 18.5 },
          label: "Доля ТБ18.5 в партиях игрока 1 за 5 игр", unit: "%",
          win_mean: 92.5, loss_mean: 14.6, delta: 77.9, normalized: 2,
          win_n: 12, loss_n: 12 },
        { metric: "p.recent.avg_set_total", args: { side: "p1", window: 5 },
          label: "Средний тотал партии игрока 1 за 5 игр", unit: "",
          win_mean: 21.4, loss_mean: 15.8, delta: 5.6, normalized: 1.71,
          win_n: 12, loss_n: 12 },
        { metric: "h2h.avg_match_total", args: { window: 10 },
          label: "Средний тотал матча в очных встречах", unit: "",
          win_mean: 74.2, loss_mean: 71.5, delta: 2.7, normalized: 0.44,
          win_n: 12, loss_n: 12 },
      ],
    });
  }

  window.PyApp = {
    constructor: (sport) => {
      const profile = sports.find(s => s.id === sport) || sports[0];
      return JSON.stringify({
        ok: true, sport: profile.id, sport_name: profile.name,
        mode: "constructor", rules: withSummaries(ctorRules),
        catalog: Object.assign({}, ctorCatalog, {
          sport: profile.id, sport_name: profile.name,
          default_total: profile.id === "table_tennis" ? 18.5 : (profile.id === "football" ? 2.5 : 5.5),
          bets: profile.bets,
        }),
        presets: ctorPresets,
        stats: { rules: ctorRules.length, matches: 12, fired: 5, skipped: 2 },
        file: "/data/constructor_rules.json",
      });
    },
    setSport: (sport) => {
      const profile = sports.find(s => s.id === sport) || sports[0];
      settings.active_sport = profile.id;
      return JSON.stringify({ ok: true, sport: profile.id, name: profile.name });
    },
    saveConstructor: (json) => {
      try {
        const data = JSON.parse(json);
        ctorRules = (data.rules || []).map((r, i) => Object.assign({}, r, {
          summary: "ЕСЛИ " + (r.conditions && r.conditions.conditions ? r.conditions.conditions.length : 0) + " условие(й) → " + ((r.action && r.action.type) || ""),
          conditions_text: "условие(я): " + (r.conditions && r.conditions.conditions ? r.conditions.conditions.length : 0),
          action_text: (r.action && r.action.type) === "skip" ? "пропустить матч" : "ТБ/ТМ партии",
        }));
        return JSON.stringify({ ok: true, errors: [], rules: withSummaries(ctorRules), mode: data.mode || "constructor", stats: { rules: ctorRules.length, matches: 12, fired: 5, skipped: 2 } });
      } catch (e) {
        return JSON.stringify({ ok: false, errors: ["Некорректный JSON"], rules: withSummaries(ctorRules) });
      }
    },
    setAlgorithmMode: (mode) => JSON.stringify({ ok: true, mode: mode === "constructor" ? "constructor" : "builtin" }),
    testConstructor: () => JSON.stringify({
      ok: true, checked: 2, items: [
        { team1: "Иванов А.", team2: "Петров С.", league: "Pro League", date: "19.10 14:30",
          h2h: 10, recent1: 5, recent2: 5,
          fired: [{ id: "r1", name: "ТБ 18.5: форма + последняя очная", details: ["Средний тотал партии игрока 1 (= 21.4) > 19"] }],
          skip: null,
          predictions: [{ label: "Партия 1 (ТБ18.5/ТМ18.5)", verdict: "ТБ 18.5", confidence: 65, reason: "Конструктор · «ТБ 18.5: форма»: Средний тотал партии игрока 1 (= 21.4) > 19" }] },
        { team1: "Сидоров К.", team2: "Кузнецов Д.", league: "TT Cup", date: "19.10 15:00",
          h2h: 4, recent1: 5, recent2: 4, fired: [], skip: null, predictions: [] },
      ],
    }),
    state: () => JSON.stringify({
      running: true, engine_running: true, stats: {
        checked: 18, sent: 3, skipped: 11, blocked_odds: 1, blocked_settings: 2, blocked_general: 1,
        no_h2h: 0, short_seq: 0, no_top: 0, by_target: {},
      },
      last_cycle: now(), last_error: null, live_matches: 24, processed: 12,
      sport: settings.active_sport, sport_name: (sports.find(s => s.id === settings.active_sport) || sports[0]).name,
      telegram_configured: false, cycles: 6, started_at: "19.10.2026 14:20",
      telegram: { enabled: true, configured: false },
      paths: { data: "/data/user/0/by.betcity.predictor/files/predictor_data", log: "…", csv: "…" },
      version: "1.0.0",
    }),
    start: () => JSON.stringify({ ok: true, running: true }),
    stop: () => JSON.stringify({ ok: true, running: false }),
    runOnce: () => JSON.stringify({ ok: true, summary: { matches: 24, upcoming: 7, signals: 2, error: null } }),
    version: () => JSON.stringify({ version: "1.0.0" }),
    settings: () => JSON.stringify({ settings, defaults: settings, sports }),
    saveSettings: (json) => JSON.stringify({ ok: true, settings: JSON.parse(json) }),
    resetSettings: () => JSON.stringify({ ok: true, settings }),
    logs: (since, limit, level, search) => {
      let items = logs.filter(e => e.id > since);
      if (level) items = items.filter(e => e.level === level);
      if (search) items = items.filter(e => e.message.toLowerCase().includes(search.toLowerCase()));
      return JSON.stringify({ items, last_id: items.length ? items[items.length - 1].id : since });
    },
    clearLogs: () => JSON.stringify({ ok: true }),
    errors: (limit) => JSON.stringify({ items: logs.filter(e => e.level === "ERROR").slice(-limit) }),
    queue: () => JSON.stringify({ items: queue.filter(m => m.sport === settings.active_sport), total: queue.length, upcoming: 2, ts: now(), error: null }),
    refreshQueue: () => JSON.stringify({ ok: true, items: queue.filter(m => m.sport === settings.active_sport), ts: now() }),
    clearProcessed: () => JSON.stringify({ ok: true }),
    predictions: (limit, sport) => {
      let items = predictions.slice();
      if (sport) items = items.filter(p => p.sport === sport);
      return JSON.stringify({ items: items.slice(0, limit), total: items.length });
    },
    results: (start, end, search, status, limit, sport) => {
      let items = results.slice();
      if (sport) items = items.filter(g => g.sport === sport);
      const needle = String(search || "").toLowerCase();
      if (needle) items = items.filter(g =>
        (g.team1 + " " + g.team2).toLowerCase().includes(needle) ||
        String(g.league || "").toLowerCase().includes(needle));
      if (start) items = items.filter(g => g.sent_at >= start);
      if (end) items = items.filter(g => g.sent_at <= end);
      if (status === "win") items = items.filter(g => g.wins > 0 && g.losses === 0);
      if (status === "loss") items = items.filter(g => g.losses > 0);
      if (status === "pending") items = items.filter(g => g.pending > 0);
      const preds = items.reduce((n, g) => n + g.rows.length, 0);
      const wins = items.reduce((n, g) => n + g.wins, 0);
      const losses = items.reduce((n, g) => n + g.losses, 0);
      const pending = items.reduce((n, g) => n + g.pending, 0);
      const finished = wins + losses;
      return JSON.stringify({
        items, total: items.length,
        summary: { games: items.length, preds, wins, losses, pending,
          hit_rate: finished ? Math.round(wins / finished * 1000) / 10 : 0 },
      });
    },
    stats: () => JSON.stringify(stats),
    analyzer: (payload) => {
      let opts = {};
      try { opts = JSON.parse(payload || "{}"); } catch (e) { opts = {}; }
      return JSON.stringify(analyzerPayload(opts));
    },
    resetStats: () => JSON.stringify({ ok: true }),
    testConnection: () => JSON.stringify({ betcity: true, telegram: null, matches: 24, error: null }),
    exportData: (kind) => JSON.stringify({
      ok: true, filename: kind + "_test.txt", mime: "text/plain",
      content: "Тестовый экспорт: " + kind,
    }),
    clearData: (what) => JSON.stringify({ ok: true, cleared: [what] }),
    saveFile: () => { },
    shareFile: () => { },
    toast: (m) => console.log("toast:", m),
    notifySignal: () => { },
    keepScreenOn: () => { },
    platform: () => "browser",
  };
})();
