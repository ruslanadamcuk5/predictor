# ARCHITECTURE

## 1. Общая схема

```text
┌──────────────────────────────────────────────────────────────┐
│ Android WebView (assets/www)                                  │
│ index.html + style.css + app.js                              │
│ состояние в JS, экраны, фильтры, редактор правил              │
└──────────────────────────┬───────────────────────────────────┘
                           │ window.PyApp.*  (синхронно)
┌──────────────────────────▼───────────────────────────────────┐
│ MainActivity.kt → Bridge (@JavascriptInterface)               │
│ каждая функция → engine_api.api_* → JSON-строка               │
└──────────────────────────┬───────────────────────────────────┘
                           │ Chaquopy
┌──────────────────────────▼───────────────────────────────────┐
│ engine_api.py — Engine (singleton), фоновый поток, API        │
│  ├─ predictor_core.py — линия, статистика, модели, результаты │
│  ├─ constructor_engine.py — правила, метрики, шаблоны          │
│  ├─ analyzer.py — разбор истории прогнозов                    │
│  └─ sports.py — справочник видов, счёт, рынки, тоталы         │
└──────────────────────────┬───────────────────────────────────┘
                           │ HTTPS
         ┌─────────────────┴──────────────────┐
         ▼                                    ▼
  d.betcity.by/api/v1/live/bets       betcity.by/ru/mstat/<id>
  live-линия и коэффициенты           статистика матча
```

`EngineService` — foreground-сервис Android. Он держит процесс живым, пока
движок запущен, и показывает постоянное уведомление. Запуск/остановка движка
идёт через `EngineService.start/stop` и параллельно через Python API.

## 2. Слои и файлы

### Android / Kotlin

- `app/src/main/java/by/betcity/predictor/MainActivity.kt`
  - создаёт WebView, скрывает системные бары;
  - инициализирует Python (`Chaquopy`);
  - `call(name, *args)` вызывает функцию `engine_api` и всегда возвращает
    строку; при исключении возвращает `{"ok": false, "error": "..."}`;
  - `Bridge` — все `@JavascriptInterface` методы;
  - сохранение/шеринг файлов, уведомления, `keepScreenOn`.
- `EngineService.kt` — foreground-сервис и уведомления.
- `AndroidManifest.xml` — permissions (INTERNET, notifications), service.
- `app/build.gradle.kts` — Chaquopy, версия, подпись debug.

### Python

- `engine_api.py`
  - singleton `Engine` (создаётся лениво функцией `engine()`);
  - фоновый поток `_loop`: `predictor.run_cycle()` → пауза
    `poll_interval_sec`;
  - JSON-API `api_*` для Kotlin;
  - очередь линии, история, фильтры, экспорт, очистка;
  - `APP_VERSION`.
- `predictor_core.py`
  - `BotSettings` — настройки и атомарное сохранение;
  - `EventLog` + файл `events.jsonl` + `predictor.log`;
  - Betcity API/линия, парсинг статистики;
  - встроенный ансамбль шести моделей (настольный теннис);
  - generic-анализ для командных видов;
  - проверка результатов, Telegram, отчёты, CSV ставок.
- `constructor_engine.py`
  - каталог метрик для каждого вида, аргументы, операторы;
  - `Context` — нормализованный матч + статистика;
  - вычисление метрик, условий, действий;
  - авто-выбор партии/стороны;
  - шаблоны (`PRESETS`, `SPORT_PRESETS`);
  - хранение правил по видам;
  - публичное описание правил для UI.
- `analyzer.py`
  - снимок контекста в момент отправки;
  - построение наблюдений, кандидатов, групп, пар, средних;
  - JSON-safe преобразование.
- `sports.py`
  - 6 видов, aliases, id Betcity;
  - `BETS`, `bet_definitions`, рынки;
  - `parse_score`, `record_from_score`, `margin`, `default_total`;
  - подписи периодов.

### Web UI

- `app/src/main/assets/www/index.html` — разметка 8 экранов и модалок.
- `style.css` — тёмная тема, карточки, чипы, адаптивность.
- `app.js` — состояние, вызовы моста, рендер, фильтры, редактор правил.

## 3. Жизненный цикл движка

1. Пользователь нажимает «Запустить».
2. Kotlin вызывает `api_start`, затем поднимает `EngineService`.
3. `Engine.start()`:
   - сохраняет `running = true`;
   - применяет глубокие параметры (`STREAK_MIN` и т.п.);
   - запускает daemon-поток `predictor-loop`.
4. Цикл:
   - проверяет `running`;
   - получает линию `get_live_matches()` активного вида;
   - для каждого предстоящего матча:
     - проверяет, не отправлялся ли уже прогноз;
     - загружает статистику Betcity;
     - выбирает режим: `constructor` / встроенный TT / generic;
     - отправляет сообщение в Telegram (или пишет в локальное хранилище);
     - сохраняет прогноз, снимок статистики, CSV-строку;
     - помечает матч обработанным.
5. `ResultChecker` в отдельном потоке периодически проверяет завершённые матчи.
6. «Остановить» ставит `running = false` и будит поток; сервис останавливается.

## 4. Поток данных прогноза

```text
live/bets JSON
  → get_live_matches(sport)
  → match {match_id, sport, team1, team2, league, date, odds, stat_link,...}
  → get_match_stats(stat_link, team1, team2, sport)
  → stats {sport, h2h_matches, recent{p1,p2}, page_total, odds...}
  → Context(match, stats)
  → evaluate (constructor) или model analysis
  → predictions [{target, label, kind, verdict, expected_side,
                  threshold, handicap, confidence_val, models_info,...}]
  → TelegramBot.mark_prediction_sent(...)
  → sent_predictions.json + analyzer sample + bets_log.csv
```

`analyzer.make_sample(match, stats)` сохраняет компактный JSON-safe снимок:
`kind: "context"`, `sport`, `page_total`, `h2h`, `recent`, `match`. Снимок
восстанавливается в `Context` при анализе, поэтому анализатор видит данные на
момент прогноза.

## 5. Хранение

`BASE_DIR` выбирается в `_resolve_base_dir()`:

1. `PREDICTOR_HOME` или `HOME`, если папка доступна для записи;
2. приватная `filesDir` Android через Chaquopy;
3. `~/predictor`;
4. `./predictor_data`.

Внутри `BASE_DIR` создаётся `predictor_data/`:

| Файл | Содержимое |
|---|---|
| `bot_settings.json` | настройки |
| `sent_predictions.json` | отправленные прогнозы + снимки + результаты |
| `processed_matches.json` | обработанные матчи |
| `report_state.json` | время последних отчётов |
| `bets_log.csv` | журнал ставок |
| `predictor.log` | текстовый лог |
| `events.jsonl` | события для экрана «Логи» |
| `constructor_rules.json` | правила настольного тенниса |
| `constructor_rules_<sport>.json` | правила остальных видов |

Все записи — атомарные: `.tmp` → `os.replace`. Настройки и правила
сериализуются с `ensure_ascii=False`, UTF-8.

## 6. Потокобезопасность

- `Engine` защищает очередь и счётчики `RLock`.
- `BotSettings` — отдельный `RLock`; `snapshot()` отдаёт глубокую копию.
- `ConstructorEngine` — `RLock` вокруг правил и статистики; правила вида
  загружаются лениво.
- `TelegramBot.sent_predictions` защищён `_lock`; анализатор копирует через
  `json.loads(json.dumps(...))`.
- `EventLog` — кольцевой буфер 2000 событий под `Lock`.
- Мост Kotlin↔JS синхронный: вызовы приходят из UI-потока WebView.

## 7. Режимы прогнозирования

`settings.algorithm_mode`:

- `builtin`:
  - `sport == table_tennis` → `_analyze_all` (ансамбль шести моделей,
    по-партийные прогнозы);
  - иначе → `_analyze_generic` (форма + H2H + линия тотала, матчевые рынки).
- `constructor`:
  - `constructor.evaluate(match, stats)` для любого вида;
  - правила сортируются по приоритету;
  - `skip` помечает матч пропущенным;
  - несколько правил могут дать несколько прогнозов.

## 8. Очередь и результаты

- `Engine.refresh_queue()` получает линию активного вида, складывает в
  `_queue`, добавляет краткие прогнозы через `_attach_predictions`.
- `get_queue(sport)` умеет фильтровать; UI обычно показывает активный вид.
- `get_results(...)` собирает игры из `sent_predictions`:
  - фильтры по дате/времени, поиску, статусу, виду спорта;
  - строки прогнозов, результаты, счёт, обоснование;
  - суммарная сводка и CSV.
- `get_predictions(limit, sport)` — плоский список для статистики.

## 9. Внешние зависимости

Вендорены в `app/src/main/python/`: `requests`, `bs4`, `soupsieve`,
`urllib3`, `certifi`, `charset_normalizer`, `idna`, `typing_extensions` и
другие чистые Python-пакеты. `pip` при сборке не используется. Нативные
библиотеки Python и Chaquopy приходят из Gradle/Chaquopy.

## 10. Границы ответственности

- `sports.py` не импортирует движок.
- `constructor_engine.py` использует `sports` и `analyzer` не импортирует.
- `analyzer.py` может использовать `constructor_engine` и `sports`.
- `predictor_core.py` использует все три модуля.
- `engine_api.py` — единственный слой, который знает про JSON-строки и UI.
- UI не содержит бизнес-логики прогнозов: только отображение, фильтры и
  формирование правил.
