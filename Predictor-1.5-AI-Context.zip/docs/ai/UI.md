# UI — WebView-интерфейс

## 1. Устройство

Интерфейс — статический WebView:

```text
app/src/main/assets/www/
  index.html   разметка экранов и модалок
  style.css    тема, сетка, карточки, чипы
  app.js       состояние, вызовы PyApp, рендер
```

Никакого сборщика, npm и фреймворка нет. JS загружается как есть. Все данные
приходят строками JSON из `window.PyApp.*`; `call()` делает `JSON.parse`.

```js
function call(name, ...args) {
  const raw = bridge[name](...args);
  return raw ? JSON.parse(raw) : null;
}
```

Если моста нет (браузерный стенд), `call` пишет предупреждение и возвращает
`null`. Для стенда подменяйте `window.PyApp` заглушкой.

## 2. Экраны и навигация

Нижняя навигация, 8 кнопок с короткими подписями:

| `data-screen` | Подпись | Назначение |
|---|---|---|
| `dashboard` | Панель | статус, кнопки, счётчики, события |
| `queue` | Очередь | live-линия и прогнозы |
| `results` | Результаты | история и фильтры |
| `logs` | Логи | журнал |
| `stats` | Статистика | сводка по видам/рынкам |
| `constructor` | Правила | конструктор |
| `analyzer` | Анализ | анализатор |
| `settings` | Настройки | параметры |

`navigate(screen)` переключает `.screen.active` и нижнюю кнопку. Статус-бар
Android скрыт в `MainActivity`; учитываются `safe-area-inset-*`.

## 3. Состояние

```js
const state = {
  screen: 'dashboard',
  running: false,
  logsSince: 0,
  logs: [],
  logLevel: '',
  logSearch: '',
  queueFilter: 'all',
  queue: [],
  results: [],
  resultsSummary: null,
  resultsTotal: 0,
  resultsSignature: '',
  resultsFilter: { from: '', to: '', search: '', status: 'all', sport: '' },
  settings: null,
  defaults: null,
  stats: null,
  predictions: [],
  sports: [],
  sport: 'table_tennis',
  sportName: 'Настольный теннис',
  timers: {},
};
```

Отдельно:

```js
state.ctor = {
  rules: [], catalog: null, presets: [], stats: null,
  mode: 'builtin', sport: 'table_tennis', editing: null,
  editingIndex: -1, test: null,
};
```

`state.an` создаётся при первом открытии анализатора:

```js
state.an = {
  filter: {sport: '', kind: 'all', target: '', min_group: 3,
           min_lift: 10, min_hits: 2},
  data: null, expanded: {failure: true, success: true},
};
```

## 4. Мост Kotlin ↔ JS

`MainActivity.Bridge` — единственный интерфейс. Все методы синхронные и
возвращают строку JSON. При ошибке Python возвращается
`{"ok": false, "error": "..."}`.

| JS | Kotlin | Python |
|---|---|---|
| `state()` | `state()` | `api_state` |
| `start()` | `start()` | `api_start` + `EngineService` |
| `stop()` | `stop()` | `api_stop` + `EngineService` |
| `runOnce()` | `runOnce()` | `api_run_once` |
| `version()` | `version()` | `api_version` |
| `settings()` | `settings()` | `api_settings` |
| `saveSettings(json)` | `saveSettings` | `api_save_settings` |
| `resetSettings()` | `resetSettings` | `api_reset_settings` |
| `setSport(id)` | `setSport` | `api_set_sport` |
| `logs(sinceId, limit, level, search)` | `logs` | `api_logs` |
| `clearLogs()` | `clearLogs` | `api_clear_logs` |
| `errors(limit)` | `errors` | `api_errors` |
| `queue()` | `queue` | `api_queue` |
| `refreshQueue()` | `refreshQueue` | `api_refresh_queue` |
| `clearProcessed()` | `clearProcessed` | `api_clear_processed` |
| `predictions(limit, sport)` | `predictions` | `api_predictions` |
| `results(start, end, search, status, limit, sport)` | `results` | `api_results` |
| `constructor(sport)` | `constructor` | `api_constructor` |
| `saveConstructor(json)` | `saveConstructor` | `api_save_constructor` |
| `setAlgorithmMode(mode)` | `setAlgorithmMode` | `api_set_algorithm_mode` |
| `testConstructor(payload, limit)` | `testConstructor` | `api_test_constructor` |
| `analyzer(payload)` | `analyzer` | `api_analyzer` |
| `stats()` | `stats` | `api_stats` |
| `resetStats()` | `resetStats` | `api_reset_stats` |
| `testConnection()` | `testConnection` | `api_test_connection` |
| `exportData(kind)` | `exportData` | `api_export` |
| `clearData(what)` | `clearData` | `api_clear_data` |
| `platform()` | `platform` | — (Kotlin) |

Особенности:

- `saveConstructor` и `testConstructor` **не принимают sport отдельным
  аргументом**: вид передаётся внутри JSON (`sport`). Python также умеет
  брать активный вид.
- `results` принимает `sport=""` — все виды, иначе id вида.
- `predictions` с `sport=""` — все виды.
- `api_set_sport` меняет глобальную настройку и возвращает
  `{ok, sport, name}`.
- Мост ловит исключения и не роняет WebView.

**Важно:** вызовы синхронные, выполняются в UI-потоке. Не вызывайте их в
циклах по сотням элементов и не делайте тяжёлых запросов без loader.

## 5. Активный вид спорта в UI

Есть два уровня:

1. **Глобальный активный вид** — `state.sport`.
   - Верхняя спортивная панель `sportBar`;
   - чипы в конструкторе `ctorSports`;
   - чипы в настройках `setSports`.
   Все три вызывают `setActiveSport(id)` → `PyApp.setSport` → backend.
   После смены:
   - обновляются `state.sport`, `state.sportName`;
   - очищается очередь;
   - сбрасывается фильтр результатов;
   - сбрасывается фильтр анализатора;
   - перезагружаются конструктор, очередь, результаты, статистика.

2. **Локальные фильтры**:
   - `resSport` — фильтр истории, `""` = все виды;
   - `anSport` — `""` = активный вид, `"all"` = все виды, иначе конкретный.
   Локальные фильтры **не меняют** глобальный активный вид.

`renderSportSelectors()` перерисовывает все селекторы. Если добавляете новый
экран с видом спорта, добавьте его контейнер сюда и в `bind()`.

### Зависимости от вида в UI

- В настройках карточки порогов моделей, обязательных моделей, ставок и партий
  показываются только для настольного тенниса; для остальных — пояснение
  `cardTeamNote`.
- В конструкторе набор метрик, сторон, рынков и целей берётся из
  `catalog.metrics`, `catalog.bets`, `catalog.side_labels`.
- В анализаторе:
  - `Матч` скрыт для настольного тенниса;
  - `Партии` скрыты для командных видов;
  - `Фора` показывается, если рынок есть у вида;
  - `Обе забьют` — только футбол/хоккей;
  - при `anSport = ""` используется активный вид; при `"all"` показываются
    все цели и рынки.

## 6. Очередь

`state.queueFilter`:

- `all` — все;
- `upcoming` — не начались и не обработаны;
- `sent` — есть отправленный прогноз;
- `processed` — обработаны.

Карточка содержит:

- вид спорта (badge);
- команды, лигу, время;
- счёт;
- коэффициенты П1/X/П2 и тотал;
- статус;
- для `sent` — прогноз и результат по матчу.

`refreshQueue()` вызывает `api_refresh_queue` (сеть) и обновляет
`state.queue`. `get_queue` не ходит в сеть, а отдаёт кэш.

## 7. Результаты

`state.resultsFilter`:

```js
{from: '', to: '', search: '', status: 'all', sport: ''}
```

- `from` / `to` — datetime-local; пустое значение не ограничивает.
- `status`: `all`, `win`, `loss`, `pending`. `win` — есть победы и нет
  поражений; `loss` — есть хотя бы одно поражение; `pending` — есть
  непроверенные прогнозы.
- `search` — команды, лига, id.
- `sport`: `""` — все.

Быстрые диапазоны: сегодня, 7 дней, 30 дней, всё время. Фильтр применяется
на backend; UI только передаёт параметры. `refreshResults()` не чаще раза в
10 секунд на экране результатов.

Карточка результата показывает:

- команды, лигу, дату/время, счёт;
- вид спорта;
- каждый прогноз: label, verdict, статус, обоснование;
- итог: зашло / не зашло / возврат / ожидает;
- сводку и CSV-экспорт.

## 8. Логи

- Уровни: `info`, `warning`, `error`, `success`.
- `logs(sinceId, limit, level, search)` возвращает `items`, `last_id`,
  `total`.
- UI хранит `logsSince`; при очистке сбрасывает в 0.
- `debug_verbose` включает подробности моделей/парсинга.
- Ошибки — отдельная вкладка/блок через `errors(limit)`.

## 9. Статистика

`api_stats` агрегирует `sent_predictions`:

- всего прогнозов, матчей, hit rate;
- по видам спорта;
- по рынкам (`match:total`, `set1:winner` и т.п.);
- последние прогнозы.

`refreshStats()` вызывается при открытии экрана и после смены вида.

## 10. Настройки

Поля соответствуют `BotSettings.DEFAULTS`:

| Группа | Поля |
|---|---|
| Основное | активный вид, интервал опроса, проверка коэффициентов, подробный лог, размер ставки |
| Telegram | enabled, token, chat_id |
| Модели TT | пороги шести моделей, обязательные модели |
| Ставки TT | разрешённые П1/П2/ТБ18.5/ТМ18.5 |
| Партии TT | set1..set5 |
| Фильтры | min_strong, min_agreement, min_confidence, min_active, vote_weight_base, min_h2h_matches |
| Отчёты | hourly, daily, daily_hour, daily_minute |
| Уведомления | on_signal, on_error, on_result |
| Движок | streak_min, window_size, window_min_hits, markov_min_sample, recency_decay, base_rate_min_n, prob_threshold |

`saveSettings` отправляет полный объект. `resetSettings` возвращает значения
по умолчанию. Пароли/токены не логируются.

## 11. Конструктор

- Список правил с приоритетом, статусом, сводкой.
- Переключатель `builtin` / `constructor`.
- Модалка правила:
  - имя, включено, приоритет, stop;
  - дерево условий (И/ИЛИ, вложенность);
  - аргументы метрики;
  - оператор и значение/вторая метрика;
  - рынок, сторона, тотал/фора, цели, уверенность.
- Шаблоны с категориями и поиском.
- «Тест на линии» — `testConstructor` с текущими правилами.
- Импорт/экспорт JSON.

При смене вида редактор закрывается/перерисовывается, чтобы не смешать
метрики разных видов.

## 12. Анализатор

- Фильтры вида, рынка, цели, минимальной группы, перевеса.
- Две колонки: неудачи и успехи.
- Раскрывающиеся строки с условиями, долями, примерами.
- «В конструктор» переносит условие; для неудач оператор инвертируется.
- `limit` по умолчанию 0 (все наблюдения).

## 13. Безопасность и стиль

- Все динамические строки вставляются через `esc()`; не используйте
  `innerHTML` с сырыми данными API.
- Никаких внешних CDN: приложение должно работать офлайн, кроме Betcity.
- Тема — тёмная, токены в `:root`:
  `--bg #0f1115`, `--card #191d27`, `--line #262c3a`,
  `--text #e8ebf2`, `--muted #8b93a7`, `--accent #e23b4e`,
  `--ok #35c48a`, `--bad #e2585f`, `--warn #e0a23c`.
- Радиусы 18/12 px, safe-area, горизонтальный скролл спортивной панели.
- Кнопки должны иметь понятную подпись и состояние disabled/loading.
- Не уменьшайте шрифт ниже 13 px; интерфейс рассчитан на телефон.

## 14. Периодичность обновлений

В `startPolling()`:

- статус — раз в 5 секунд вне панели;
- результаты — раз в 10 секунд на экране результатов;
- конструктор — раз в 15 секунд, если не открыт редактор.

Логи/очередь обновляются по действию или при открытии, чтобы не грузить
UI-поток.

## 15. Браузерный стенд

Для проверки без телефона используется отдельная копия `www` с
`mock.js`, подменяющим `window.PyApp`. Стенд не входит в APK. Если он нужен,
соберите его из `tools/ui_harness/` (см. `TESTING.md`) и откройте
`index.html` в браузере. Проверяйте консоль: ошибок быть не должно.
