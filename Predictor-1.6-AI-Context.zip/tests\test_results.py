# -*- coding: utf-8 -*-
# ??????????? ????? ?????????????? ?????. ????????? ?? ????? ???????.
import os
import tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FIXTURES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fixtures")
"""Проверка расчёта результатов: прогноз -> завершённые партии -> статистика."""
import json
import os
import shutil
import sys

HOME = os.path.join(tempfile.gettempdir(), "predictor-tests", "pred_result")
if os.path.exists(HOME):
    shutil.rmtree(HOME, ignore_errors=True)
os.makedirs(HOME, exist_ok=True)
os.environ["HOME"] = HOME

APP = os.path.join(ROOT, "app", "src", "main", "python")
sys.path.insert(0, APP)

import predictor_core as core

fails = []


def check(name, cond, detail=""):
    if cond:
        print("  OK   %s" % name)
    else:
        print("  FAIL %s %s" % (name, detail))
        fails.append(name)


settings = core.BotSettings()
pred = core.PredictorEnsemble(settings=settings)
bot = pred.telegram

# --- создаём прогноз на 2 партии: победитель и тотал ---
predictions = [
    {"target": "set1", "label": "Партия 1 (П1/П2)", "kind": "winner",
     "verdict": "П1", "confidence_val": 0.4, "models_info": "test"},
    {"target": "set1", "label": "Партия 1 (ТБ18.5/ТМ18.5)", "kind": "total",
     "verdict": "ТМ 18.5", "confidence_val": 0.4, "models_info": "test"},
    {"target": "set2", "label": "Партия 2 (П1/П2)", "kind": "winner",
     "verdict": "П1", "confidence_val": 0.4, "models_info": "test"},
]
mid = bot.send_message("test")
pid = bot.mark_prediction_sent("A", "B", "2026-10-19 12:00", predictions, mid, "L", {})

# --- подменяем счёт: П1 выиграл 1-ю партию 11:7 (тотал 18 -> ТМ), 2-ю 9:11 ---
pred.get_live_match_score = lambda t1, t2: "11:7, 9:11"
pred.result_checker.get_live_match_score = pred.get_live_match_score

print("=== прогон проверки ===")
pred.result_checker.check_pending_predictions()

data = bot.sent_predictions[pid]
results = data.get("set_results") or []
print("результатов:", len(results))
for r in results:
    print("   ", r.get("target"), r.get("kind"), "->",
          "зашла" if r.get("success") else "не зашла",
          "| счёт:", r.get("score"), "| тотал:", r.get("total"))

check("сохранены оба вида ставок", len(results) == 3, str(len(results)))
check("есть победитель", any(r.get("kind") == "winner" for r in results))
check("есть тотал", any(r.get("kind") == "total" for r in results))

winner = next((r for r in results if r.get("kind") == "winner"), {})
total = next((r for r in results if r.get("kind") == "total"), {})
check("П1 зашла (11:7)", winner.get("success") is True, str(winner))
check("ТМ 18.5 зашла (11:7=18)", total.get("success") is True, str(total))

payload = bot.stats_payload()
print("=== статистика ===")
print("  всего:", payload["total"], "hit:", payload["hit_rate"])
check("2 победы", payload["total"]["wins"] == 2, str(payload["total"]))
check("1 поражение (П1 в 9:11)", payload["total"]["losses"] == 1, str(payload["total"]))
check("hit rate 66.7", payload["hit_rate"] == 66.7, str(payload["hit_rate"]))

# --- заменяем результат set2 на выигрышный ---
bot.update_set_result(pid, "set2", {
    "target": "set2", "kind": "winner", "success": True,
    "score": "11:9", "total": 20, "label": "Партия 2", "verdict": "П1",
})
payload = bot.stats_payload()
check("3 победы", payload["total"]["wins"] == 3, str(payload["total"]))
check("0 поражений", payload["total"]["losses"] == 0, str(payload["total"]))
check("hit rate 100", payload["hit_rate"] == 100.0, str(payload["hit_rate"]))

print()
if fails:
    print("ПРОВАЛЕНО: %s" % ", ".join(fails))
    sys.exit(1)
print("ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ")
